<?php

    require_once './helpers/DB.php';
    require_once './helpers/Routes.php';
    require_once './helpers/Response.php';
    require_once './helpers/Request.php';
    require_once './helpers/Error.php';
    require_once './helpers/Middleware.php';
    require_once './helpers/UI.php';
    require_once './helpers/Form.php';
    require_once './helpers/TemplateHTML.php';
    require_once './helpers/Mitarbeiter.php';

?>