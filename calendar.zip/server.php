<?php
    exec('php -S localhost:8080 -t public index.php');
?>